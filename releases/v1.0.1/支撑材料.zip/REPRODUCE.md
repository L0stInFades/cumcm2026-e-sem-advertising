# 复现说明（run `20260912-041501-ae773aa`）

本目录内所有结果均由 Modal 云端按下列阶段生成；本地只提交任务、下载和核对 SHA-256。

- 代码版本：git `40f5b6e5167d1986828ea7bf74cd7dab9adc3567`（分支 `main`）
- 运行环境：Python 3.11.12，Linux-4.19.0-gvisor-x86_64-with-glibc2.36
- 依赖版本：cvxpy==1.6.5, highspy==1.10.0, hypothesis==6.131.9, matplotlib==3.10.3, mypy==1.15.0, networkx==3.4.2, numba==0.61.2, numpy==2.2.6, openpyxl==3.1.5, ortools==9.12.4544, pandas==2.2.3, pyarrow==20.0.0, pymupdf==1.26.7, pytest==8.3.5, ruff==0.11.10, scikit-learn==1.6.1, scipy==1.15.3, statsmodels==0.14.4

## 阶段

| 阶段 | 状态 | 用时 (s) | 输出摘要 | Modal 任务 |
|---|---|---:|---|---|
| allocate | completed | 63.0 | `724259d703dc30b5` | `ta-01M2A78A6ADGMXBYBQKAWA9RPR` |
| classify | completed | 1.0 | `09b0ee01107ba8e7` | `ta-01M2A5NW550BF8S87FP0NXP8ER` |
| eda | completed | 3.0 | `de671c38a6462570` | `ta-01M2A6XWCPB4CBJ1BH7MGQ969R` |
| figures | completed | 27.0 | `a50aedf500ef32de` | `ta-01M2A7K6VWXTF6V38QW4G10RDR` |
| fmt | completed | 1.0 | `92ad4ecda5f4fe00` | `ta-01M2AXPZEEEH7A3D0EWQXRPEHR` |
| forecast | completed | 13.0 | `b7ee2ae20550f38e` | `ta-01M2A78A6ADGMXBYBQKAWA9RPR` |
| ingest | completed | 1.0 | `02e38a853d4c7bbd` | `ta-01M2921SRRS59ZGNGZWMNNKSSR` |
| lint | completed | 28.0 | `ed4b665d3277fb11` | `ta-01M2AXQMJZKYM7JYTRT27NJYDR` |
| package | running | 0.0 | `` | `ta-01M2AXT8RFB0KTD5J8AASWGV5R` |
| paper | completed | 70.0 | `2aa41e1c5ea012e5` | `ta-01M2AXT8RFB0KTD5J8AASWGV5R` |
| qa | completed | 1.0 | `3399a0a45e6fcd2c` | `ta-01M2AXT8RFB0KTD5J8AASWGV5R` |
| release | completed | 0.0 | `3439d1f5ca7384e7` | `ta-01M2A8AGMQ2025VS23B7AVG8TR` |
| results | completed | 2.0 | `79ce6f23421e94aa` | `ta-01M2A78A6ADGMXBYBQKAWA9RPR` |
| tables | completed | 0.0 | `01fba99d8e19e9ba` | `ta-01M2A78A6ADGMXBYBQKAWA9RPR` |
| test | completed | 30.0 | `3cc664cf595de940` | `ta-01M2AXQMJZKYM7JYTRT27NJYDR` |
| validate | completed | 0.0 | `8ad89df6a5eca27a` | `ta-01M2921SRRS59ZGNGZWMNNKSSR` |

## 复现命令

### A. 云端（本文使用的方式，需要 Modal 账号）

```bash
python3 tools/cli.py provision
python3 tools/cli.py run ingest,validate --new-run
python3 tools/cli.py run allocate --size medium
python3 tools/cli.py run classify --size medium
python3 tools/cli.py run eda --size medium
python3 tools/cli.py run figures --size medium
python3 tools/cli.py run forecast --size medium
python3 tools/cli.py run lint --size medium
python3 tools/cli.py run package --size medium
python3 tools/cli.py run paper --size medium
python3 tools/cli.py run qa --size medium
python3 tools/cli.py run release --size medium
python3 tools/cli.py run results --size medium
python3 tools/cli.py run tables --size medium
python3 tools/cli.py run test --size medium
python3 tools/cli.py release --version <tag>
```

各阶段的确切参数（线程数、逐级时限）见每个阶段目录下 `manifest.json` 的 `params` 字段，
以及 `docs/RUNBOOK.md` 第 7 节。

### B. 本地（不需要任何云端账号）

```bash
pip install pandas numpy openpyxl pyarrow networkx matplotlib ortools highspy
python3 tools/run_local.py --quick        # 数分钟，得到 result1-4.xlsx、图与表
python3 tools/run_local.py                # 使用默认（较大）预算
```

本地驱动脚本调用的是同一批阶段函数，只是把云端卷换成本地目录；
附件需按原样放在 `附件/` 下。论文排版阶段（paper/qa/package/release）需要 TeX Live 与中文字体，
不在本地默认序列中。

每个阶段目录下的 `manifest.json` 记录输入、输出散列、参数与环境；`events.jsonl` 为结构化日志。
