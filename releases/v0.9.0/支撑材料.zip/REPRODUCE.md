# 复现说明（run `20260912-041501-ae773aa`）

本目录内所有结果均由 Modal 云端按下列阶段生成；本地只提交任务、下载和核对 SHA-256。

- 代码版本：git `9affd17f540e7631cb8c1804c8911d4000d89b0b`（分支 `main`）
- 运行环境：Python 3.11.12，Linux-4.19.0-gvisor-x86_64-with-glibc2.36
- 依赖版本：cvxpy==1.6.5, highspy==1.10.0, hypothesis==6.131.9, matplotlib==3.10.3, mypy==1.15.0, networkx==3.4.2, numba==0.61.2, numpy==2.2.6, openpyxl==3.1.5, ortools==9.12.4544, pandas==2.2.3, pyarrow==20.0.0, pymupdf==1.26.7, pytest==8.3.5, ruff==0.11.10, scikit-learn==1.6.1, scipy==1.15.3, statsmodels==0.14.4

## 阶段

| 阶段 | 状态 | 用时 (s) | 输出摘要 | Modal 任务 |
|---|---|---:|---|---|
| allocate | completed | 51.0 | `0ea04bf6f53ad840` | `ta-01M29QM8HG9WQTS4APS8BEXCDR` |
| classify | completed | 1.0 | `51c608417cdac4e2` | `ta-01M29QM8HG9WQTS4APS8BEXCDR` |
| eda | completed | 1.0 | `edfe1358e71672d1` | `ta-01M29QM8HG9WQTS4APS8BEXCDR` |
| figures | completed | 23.0 | `77c7e5184b346868` | `ta-01M29QM8HG9WQTS4APS8BEXCDR` |
| forecast | completed | 11.0 | `1d5db747a8e02b23` | `ta-01M29QM8HG9WQTS4APS8BEXCDR` |
| ingest | completed | 1.0 | `02e38a853d4c7bbd` | `ta-01M2921SRRS59ZGNGZWMNNKSSR` |
| lint | completed | 20.0 | `cd5e1ca31d0d8559` | `ta-01M29QM8HG9WQTS4APS8BEXCDR` |
| package | running | 0.0 | `` | `ta-01M29RBPG8AK1YDB3F2NRG41TR` |
| paper | completed | 47.0 | `0dacf486517b9e48` | `ta-01M29R8Z0DB3FDZSX0RFPJGY3R` |
| qa | completed | 1.0 | `90401fb6169d9753` | `ta-01M29R8Z0DB3FDZSX0RFPJGY3R` |
| results | completed | 1.0 | `bbad2b8a99ec8cfe` | `ta-01M29QM8HG9WQTS4APS8BEXCDR` |
| tables | completed | 1.0 | `3aa4744a0e04c01b` | `ta-01M29QM8HG9WQTS4APS8BEXCDR` |
| test | completed | 19.0 | `6d3e14a65892b4a5` | `ta-01M29QM8HG9WQTS4APS8BEXCDR` |
| validate | completed | 0.0 | `8ad89df6a5eca27a` | `ta-01M2921SRRS59ZGNGZWMNNKSSR` |

## 复现命令

```bash
python3 tools/cli.py provision
python3 tools/cli.py run ingest,validate --new-run
python3 tools/cli.py run <科学阶段...> --size medium
python3 tools/cli.py run lint,test,paper,qa,package,release
python3 tools/cli.py release --version <tag>
```

每个阶段目录下的 `manifest.json` 记录输入、输出散列、参数与环境；`events.jsonl` 为结构化日志。
