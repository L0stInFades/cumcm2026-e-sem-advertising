# 结果总览（供论文撰写使用）

所有数字来自同一次云端 run（见 `.forge/last_run` 与本文件末尾的 run 记录）；论文中的数字只能引用 `\val<Key>` 宏（各阶段 `numbers.json` 汇总）或 `tables` 阶段生成的表。下文的"数值"栏为该 run 的实际值，供撰写者核对。

## 阶段与产物

| 阶段 | 内容 | 主要文件 |
|---|---|---|
| `eda` | 问题一：KPI、集中度、日历/假日回归、注册归因、弹性 | `unit_kpis.*`, `calendar_regression.*`, `calendar_regression_summary.json`, `attribution.json`, `attribution_fit.*`, `attribution_rates.*`（自助区间与边界标记）, `attribution_diagnostics.json`（共线性、设定摆动、三块分解）, `optimal_cut.json`（式 (5) 的联合不确定性）, `unit_response.*`, `concentration.json`, `lorenz.*`, `day_type_profile.*`, `daily_totals.*`, `unit_daily.*` |
| `classify` | 问题二：五类分类 | `classification.*`（逐词），`classification_by_label.*`, `classification_per_unit.*`, `classification_dual_axis.*`, `classification_summary.json`, `axis_diagnostics.json`（两轴共线性与效率口径）, `engagement_variant.json`, `classification_check.json`（独立复核） |
| `allocate` | 问题三：分配 | `allocation.*`（逐词逐日），`allocation_summary.*`（单元-日汇总），`allocation_audit.json`, `calibration_check.json`（含有符号偏差与重标定不变性）, `bootstrap.*`, `sensitivity.*`（14 情形，带 `relaxation` 标记）, `sensitivity_monotonicity.json`（单调性门禁）, `baseline_feasibility.json`, `duplication_exposure.json`, `cross_unit_counterfactual.*`, `plan_feb_annual_avg.*`（2 月窗口全 12 单元备选）, `window_budget_alternative.*`, `keyword_parameters.*`, `position_models.json` |
| `forecast` | 问题四：预测 + 随机分配 | `backtest.*`（含 `calendar_wide` 部署区间）, `backtest_summary.*`, `unit_forecasts.*`, `budgets.*`, `budget_alternatives.json`, `plan.*`（逐词逐日，含均值与 10/50/90 分位）, `plan_zero_rows.*`（零预算单元）, `plan_annual_alt.*`（全年日均口径完整方案）, `plan_by_unit_day.*`（含 `p_top_mean`/`p_first_mean`/`cpc_scenario_mean`）, `plan_by_unit.json`, `joint_relaxation.*`（两层分解的联合上界）, `allocation_audit.json` |
| `results` | result2/3/4.xlsx | 阶段目录根 |
| `figures` | 论文图 | `figures/*.pdf` + `*.png` |
| `tables` | 论文表 | `tables/*.tex` + `*.csv` |

## 问题一：投放策略合理性与假日效应

**方法一句话**：单元级漏斗 KPI 与关键词集中度刻画"创意质量 / 关键词管理 / 出价预算"；带周几、月份、节假日与调休哑变量的对数线性回归（HC3 稳健标准误）+ Mann–Whitney 检验量化时间规律与假日效应；非负最小二乘把日注册数归因到各推广单元的点击（MDR-0002/0003）。

**关键数值（键名）**：`TotalSpend`, `TotalClicks`, `TotalImpressions`, `TotalRegs`, `OverallCtrPct`, `OverallCpc`, `TopSharePct`, `FirstSharePct`, `TopClickSharePct`, `TopSpendSharePct`, `TopCpc`, `OtherCpc`, `BiggestUnitId`, `BiggestUnitSpendSharePct`, `ActiveKeywords`, `ZeroKeywords`, `UniqueKeywordIds`, `SharedKeywordIds`, `GiniSpendActive`, `TopTenSpendSharePct`, `TopHundredSpendSharePct`, `Holiday{Reg,Spend,Clicks,Imp}EffectPct/CiLow/CiHigh/P`, `HolidayRegGivenSpendEffectPct/CiLow/CiHigh/P`, `RegSpendElasticity(Se)`, `{Monday,Saturday,Sunday,AdjustedWorkday,PreHoliday,PostHoliday}RegEffectPct/RegP`, `MondayRegGivenSpendEffectPct`, `SundayRegGivenSpendEffectPct`, `HolidayCpcEffect/P`, `MondayCpcEffect/P`, `RegCalendarRsq`, `RegWeekdayWaldP`, `HolidayRegMedianRatio`, `HolidayRegMannWhitneyP`, `AttributionLambda`, `AttributionRsq`, `AttributionHoldoutRsq`, `AttributionHoldoutMape`, `BaselineRegsPerDay`, `PooledRegRatePerHundredClicks`, `AttributedRegs`, `CostPerAttributedReg`, `UnitsWithOwnRate`, `PooledGamma`, `PooledGammaSe`, `MinUnitGamma`, `MaxUnitGamma`, `UnitsWithOwnGamma`.

**v1.0.1 新增键**：回归估计与采用值的区分 `MinUnitGammaHat`, `MaxUnitGammaHat`, `UnitsGammaHatBelowOne`, `UnitsGammaHatAboveOne`, `GammaAboveOne{UnitId,Hat,Se,T,ActiveDays}`, `GammaShort{UnitId,ActiveDays,Hat,Days}`, `GammaMinActiveDays`；上限依据 `{Min,Max,Median}PninefiveSpendRatio`；式 (5) 的不确定性 `{Holiday,Monday,Sunday}{OptimalCutPct,OptimalCutCiLowPct,OptimalCutCiHighPct,ActualCutPct,ThetaStar,ProbOptimalDeeperPct,CutAtPooledGammaPct,DemandDeltaCiLowPct,DemandDeltaCiHighPct}`, `ThetaCiLow/High`, `HolidayThetaStarInsideCi`；对数尺度分解 `HolidayDemandLogSharePct`, `HolidaySupplyLogSharePct`；归因诊断 `AttributionZeroBoundUnits`, `AttributionConditionNumber`, `AttributionMaxSwingRatio`, `AttributionBoot`, `Decomp{InterceptRegs,InterceptPct,CalendarRegs,CalendarPct,SemRegs,SemPct,NonSemPerDay}`；展现结构 `OtherRegionClickSharePct`, `OtherRegionImpSharePct`, `TopOverOtherCtrRatio`。

**表**：`tab_unit_kpis`（各单元年度 KPI）、`tab_calendar_effects`（日历/假日效应，注册、消费、点击）、`tab_attribution_response`（各单元注册率与来源、归因注册（按实际采用的注册率，MDR-0010）、注册成本、单元估计 $\hat\gamma_u$ 及其 SE、$R^2$、采用的 $\gamma_u$ 与来源）。

**图与建议图注**：
- `fig_daily_series`：2025 年日消费额、日点击量与日新注册数（细线为日值，粗线为 7 日滑动均值；阴影为法定节假日，虚线为调休上班日）。
- `fig_calendar_effects`：周几、法定节假日、调休、假前/假后对日注册数、消费额、点击量的效应（相对周三/普通日，%），HC3 稳健 95% 置信区间。
- `fig_unit_kpis`：各推广单元年度消费占比（左）与 CPC–CTR 散点（右，气泡面积 ∝ 消费占比，标签为单元 ID 后四位）。
- `fig_lorenz`：关键词消费额与点击量的 Lorenz 曲线（按消费降序累计）。
- `fig_response_curves`：各单元日点击量–日消费额（双对数）散点与幂函数响应曲线（γ 带 * 者使用合并弹性）。
- `fig_attribution`：日注册数与归因回归拟合值（虚线右侧为留出期）。

**验证结论**：HC3 回归与 Mann–Whitney 检验结论一致；归因模型留出期 R² 见 `AttributionHoldoutRsq`；弹性估计 R² 见 `tab_attribution_response`。

**值得写进论文的发现**：法定节假日日注册数总效应 −73.7%（95% CI [−80.0, −65.5]），其中控制当日消费额后仍有 −24.6%（[−40.0, −5.3]，p = 0.015）——约三分之一来自需求侧，其余来自公司假日主动减投（消费额 −76.7%）；周一与周日的注册下降（−53.8%、−47.4%）几乎完全由减投解释（控制消费后不显著，见 `MondayRegGivenSpendEffectPct`、`SundayRegGivenSpendEffectPct`）。CPC、CTR 无显著假日效应，上方位占比在假日略降。

**局限**：注册只有日总量，归因为回归推断而非真实追踪；假日效应包含公司主动停投的成分（用控制消费额的模型分离）。

## 问题二：关键词五分类

**方法一句话**：成本 = 年度消费额（对数尺度），效益 = 熵权复合指数（点击、浏览、注意力时长、归因注册），阈值用两类 Fisher–Jenks 自然断点（主），中位数与高斯混合为稳健性对照；无效词 = 零消费且零点击（MDR-0001/0004）。

**关键数值（键名）**：`{Gold,Key,Potential,Problem,Invalid}Count`, `{...}SpendSharePct`, `{...}Cpc`, `CostThresholdYuan`, `CostThresholdLog`, `BenefitThreshold`, `Weight{Clicks,Views,Engagement,Reg}`, `AgreementJenksMedianPct`, `AgreementGmmJenksPct`, `AgreementJenksEqualWeightsPct`, `EntropyEqualSpearman`, `MedianCostThresholdYuan`, `GmmCostThresholdYuan`.

**v1.0.1 新增键**：两轴共线性与口径对照 `AxisPearson`, `AxisPearsonRsq`, `AxisSpearman`, `AxisSpearmanClicks`, `AxisSpearmanEfficiency`, `AxisEfficiencyAgreementPct`, `Eff{Gold,Key,Potential,Problem,Invalid}Count`, `{Gold,Key,Potential,Problem,Invalid}ClickSharePct`, `GoldSpendSharePctFine`, `EngagementVariantAgreementPct`。

**表**：`tab_class_summary`（各类数量、消费占比、CPC、平均效益、归因注册）、`tab_class_robustness`（不同阈值方法/权重下的类别数量）、`tab_class_per_unit`（单元 × 类别）。

**图与建议图注**：
- `fig_cost_benefit`：关键词成本–效益散点（横轴年度消费额对数，纵轴综合效益指数；虚线为自然断点阈值；颜色为类别；无效词零消费未画出）。
- `fig_class_thresholds`：对数消费额与效益指数的直方图及三种阈值方法的位置。

**验证结论**：`classification_check.json` 全部通过（标签由原始列独立重推、无效词定义、计数）。

**局限**：效益指数依赖归因注册率（单元级）；阈值为相对（数据驱动）而非业务绝对标准。

**结果文件**：`result2.xlsx`（2227 行，五个类别列 1/0 标记）。

## 问题三：关键词选择与投放模型（2025-02-01–08、08-01–08）

**方法一句话**：每个单元-日求解可分离凹规划 $\max\sum_i \rho_i c_i (x_i/s_i)^{\gamma_u}$ s.t. 预算（= 当日实际消费）与上限、最小投放额 0.5 元（选择机制）；两阶段拉格朗日 + 精确注水求解，独立校验器复核 KKT、配对转移与凸松弛上界（MDR-0005/0006/0007）。

**关键数值（键名）**：`QthreeBudget{Feb,Aug}`, `QthreeOptRegs{..}`, `QthreePropRegs{..}`, `QthreeOptClicks{..}`, `QthreePropClicks{..}`, `QthreeActualClicks{..}`, `QthreeRegGainPct{..}`, `QthreeRegGainCiLow/High{..}`, `QthreeClickGainPct{..}`, `QthreeEqualRegGainPct{..}`, `QthreeUnitDays{..}`, `QthreeUnits{..}`, `QthreeSelectedKeywords{..}`, `QthreeEligibleKeywords{..}`, `QthreeAvgCpc{..}`, `QthreePropCpc{..}`, `QthreeWindowRegs{..}`, `QthreeWindowGainPct{..}`, `QthreeAuditGroups`, `QthreeMaxCvxGap`, `QthreeAggregateGapPct`, `QthreeCalibrationMape`, `QthreeCalibrationMedianApe`, `QthreeRows`, `QthreeCapMultiplier`, `QthreeMinSpend`.

**v1.0.1 新增键**：基线占优 `QthreeMinOptPropRatio`, `QthreeUnitDaysOptAtLeastProp`, `QthreePropBelowFloor(Pct)`, `QthreePropPositiveCoords`；重复投放暴露 `QthreeDupKeywordDays`, `QthreeDupRegs(SharePct)`, `QthreeDupSpend(SharePct)`；校准符号与不变性 `QthreeSignedBiasPct{Feb,Aug}`, `QthreeGainRescaledPct{Feb,Aug}`, `QthreeGainShiftPp`, `QthreeSpendWeightedMape`；跨单元反事实 `QthreeCrossUnitGainPct{Feb,Aug}`, `QthreeCrossUnitDays{Feb,Aug}`；2 月全单元备选 `QthreeFebAlt{Rows,Units,Budget,Regs,Clicks,Keywords}`；灵敏度读数 `QthreeFloorCostPct{Feb,Aug}`, `QthreeSelected{Base,NoFloor}{Feb,Aug}`, `QthreeKappaOneGainPct{Feb,Aug}`, `QthreeKappaClipGainPct{Feb,Aug}`, `QthreeDupBestGainPct{Feb,Aug}`, `QthreeSens{MinGainPct,MaxGainPct,Scenarios}`；跳出率因子 `KappaAtBoundPct`, `KappaMedian`, `KappaRows`。

**表**：`tab_q3_summary`（各窗口各单元：预算、候选/入选词、历史比例 vs 最优注册、提升与自助区间、CPC）、`tab_q3_daily`（逐日汇总）、`tab_q3_window_budget`（窗口预算跨日调配的备选结果）、`tab_q3_sensitivity`（上限倍数、弹性、预算、问题词处理、最小投放额）、`tab_verification`（校验汇总）。

**图与建议图注**：
- `fig_q3_gain`：两个窗口逐日预期注册量（最优分配 vs 按历史比例 vs 均匀分配）与弹性自助抽样得到的提升分布。
- `fig_allocation_shift`（替换原 `fig_allocation_mix`，MDR-0010）：8 月窗口每个入选关键词的最优窗口日均投放 vs 2025 年日均消费（双对数，按类别着色，附 45° 线与上限倍数线）；右图为各类候选词数与至少入选一天的词数。位于上限线之上的一簇点是历史日均消费低于 $m/\mu$ 的长尾词（上限即最小投放额），其预算与注册份额见 `QthreeFloorSpendSharePctAug`、`QthreeFloorRegsSharePctAug`。

**验证结论**：全部单元-日问题通过独立审计（可行性、KKT、配对转移/剔除/插入不可改进、凸松弛上界）；`QthreeAggregateGapPct` 为总体最优性界。响应模型校准 MAPE 见 `QthreeCalibrationMape`。

**局限**：关键词响应曲线由年度汇总 + 单元弹性外推；2 月窗口只有 2 个单元有实际消费。

**备选解释**：窗口预算跨日调配（`tab_q3_window_budget`）；预算 ±20%（`tab_q3_sensitivity`）。

**结果文件**：`result3.xlsx`（日期、方案ID、推广单元、关键词、投入金额、预期展位、预期点击量、预期浏览量、预期注册量）。

## 问题四：2026-09-11–17 的最优策略与期望范围

**方法一句话**：单元级日历回归预测效率乘子、CPC、CTR、展位占比（滚动回测对照季节朴素与 28 日均值），预算 = 2025 同期各单元消费；两层分配（跨日 + 日内）后用 500 个蒙特卡罗情景给出竞价、展现量、展位、点击、浏览、注册的期望与 10%–90% 范围（MDR-0008）。

**关键数值（键名）**：`QfourBudget`, `QfourBudgetAnnualAlt`, `QfourUnits`, `QfourSkippedUnits`, `QfourRows`, `QfourSelectedKeywords`, `Qfour{Clicks,Imp,Views,Regs}{Mean,Low,High}`, `QfourCpc{Mean,Low,High}`, `QfourPosition{Mean,Low,High}`, `QfourScenarios`, `QfourAuditGroups`, `QfourRefClicks`, `QfourClickGainVsRefPct`, `Backtest{Calendar,Naive,Mean}Mae{Eff,Cpc,Ctr,Top,Clicks}`, `Backtest{Calendar,Naive}Mape{..}`, `BacktestCalendarCoverage{..}`, `Backtest{Calendar,Naive}Pinball{..}`.

**v1.0.1 新增键**：两层分解的联合界 `QfourJointGapPct`, `QfourJointMaxGapPct`, `QfourJointMaxGapUnit(Regs)`, `QfourJointMaxGapBigPct`, `QfourJointBigUnits`, `QfourJointUnits`, `QfourDetRegs`；区间宽度与回测 `QfourWidthInflation{Median,Min,Max}`, `BacktestWideCoverage{Eff,Cpc,Ctr,Top,First,Clicks}`, `BacktestWidePinball*`, `Backtest{Calendar,Mean,Wide}Coverage{Min,Max}`, `BacktestOrigins`, `BacktestUnits`；展位结构 `QfourPtopPct`, `QfourPfirstPct`, `QfourPmidPct`；蒙特卡罗精度 `QfourRegsMcSe`, `QfourRegsMcZ`；口径 `QfourCpcScenarioMean`, `QfourBudgetAltOverMainPct`；备选方案 `QfourAlt{Rows,Units,Keywords,Spend,Clicks,Regs}`。

**表**：`tab_backtest`（目标 × 模型的 MAE/RMSE/MAPE/pinball/覆盖率）、`tab_q4_ranges`（题目要求的六个量——竞价/CPC、展现量、展现位、点击量、浏览量、注册量——的 7 日期望与 10%–90% 范围，以及单关键词–日的中位期望与中位范围）、`tab_q4_daily`（逐日投入、CPC、展现量、展位、点击量、浏览量、注册量的期望与范围）、`tab_q4_units`（各单元预算、弹性、候选词、点击与注册范围）。

**图与建议图注**：
- `fig_backtest`：滚动回测（2025-10-09 起每周一个起点，7 天步长）各目标的 MAE 与 80% 区间覆盖率，日历回归 vs 季节朴素 vs 28 日均值。
- `fig_q4_plan`：2026-09-11 至 17 逐日预期点击量、注册量与 CPC（点为期望，带为 10%–90% 分位）。
- `fig_q4_units`：各单元 7 天预期注册量及 10%–90% 范围（对数轴）。

**验证结论**：跨日与日内分配问题全部通过独立审计；回测指标见 `tab_backtest`。合计量的区间按共单调（分位数相加）聚合，是偏宽的保守一侧；CPC 与展位不可加，用点击量加权平均各单元–日的分位数（MDR-0011）。

**局限**：预测点在样本末 8.5 个月之后，只能依赖日历结构（周几、9 月效应），区间反映 2025 年的残差与月份间波动；2026 年的市场趋势无法从数据识别。

**备选解释**：预算按全年日均折算（`QfourBudgetAnnualAlt` = 27,347 元 vs 同期 23,488 元）。两种预算读法下的确定性预期注册量分别为 `QfourRegsExpectedSamePeriod`（1187）与 `QfourRegsExpectedAnnualAlt`（2327）：同期读法把 81% 的预算留给 9657930100（2025 年 9 月中旬其他单元几乎停投），而全年日均读法会把资金重新分配到效率更高但 9 月停投的单元（9811363528、9630806627 等），预期注册量约翻倍——论文应把这一点作为对公司 9 月投放节奏的建议。

**结果文件**：`result4.xlsx`（同 result3 结构，填入期望值）。

## 本次 run 的全部登记数字

run：`20260912-041501-ae773aa`（ingest、validate、eda、classify、allocate、forecast、results、figures、tables、lint、test 全部 completed；paper/qa/package/release 门禁见 CHANGELOG）。以下为各阶段 `numbers.json` 的内容（论文撰写阶段重跑后的最终值），论文中以 `\val<键>` 引用；此处仅供撰写者核对。
USED 205 REGISTERED 277
MISSING (used in manuscript, not registered): []
UNUSED registered keys: 72


### `allocate` 阶段登记的数字（59 个）

| 键 | 值 | 键 | 值 |
|---|---|---|---|
| `QthreeActualClicksAug` | 35,812 | `QthreeActualClicksFeb` | 5,655 |
| `QthreeAggregateGapPct` | 0.080 | `QthreeAuditGroups` | 107 |
| `QthreeAvgCpcAug` | 1.3052 | `QthreeAvgCpcFeb` | 1.9273 |
| `QthreeBudgetAug` | 37,483.78 | `QthreeBudgetFeb` | 13,681.15 |
| `QthreeCalibrationMape` | 32.92 | `QthreeCalibrationMedianApe` | 22.00 |
| `QthreeCapMultiplier` | 4.0 | `QthreeCappedKeywordDays` | 339 |
| `QthreeClickGainPctAug` | 15.87 | `QthreeClickGainPctFeb` | 12.05 |
| `QthreeCvxTinyGroups` | 13 | `QthreeEligibleKeywordsAug` | 1337 |
| `QthreeEligibleKeywordsFeb` | 286 | `QthreeEqualRegGainPctAug` | 77.01 |
| `QthreeEqualRegGainPctFeb` | 88.54 | `QthreeFloorKeywordDaysAug` | 1259 |
| `QthreeFloorRegsSharePctAug` | 5.49 | `QthreeFloorSpendSharePctAug` | 1.68 |
| `QthreeMaxCvxGap` | 2.01e-01 | `QthreeMaxCvxGapInformativePct` | 3.404 |
| `QthreeMaxCvxGapPct` | 20.1 | `QthreeMaxGainUnitAug` | 9700005700 |
| `QthreeMaxUnitGainPctAug` | 210.5 | `QthreeMeanSelectedAug` | 21.7 |
| `QthreeMinGainUnitAug` | 9773660250 | `QthreeMinSpend` | 0.50 |
| `QthreeMinUnitGainPctAug` | 0.7 | `QthreeOptClicksAug` | 28,718.7 |
| `QthreeOptClicksFeb` | 7,098.4 | `QthreeOptRegsAug` | 2237.43 |
| `QthreeOptRegsFeb` | 516.42 | `QthreePropClicksAug` | 24,784.5 |
| `QthreePropClicksFeb` | 6,335.2 | `QthreePropCpcAug` | 1.5124 |
| `QthreePropCpcFeb` | 2.1595 | `QthreePropRegsAug` | 1748.04 |
| `QthreePropRegsFeb` | 459.65 | `QthreeRegGainCiHighAug` | 28.57 |
| `QthreeRegGainCiHighFeb` | 13.39 | `QthreeRegGainCiLowAug` | 27.53 |
| `QthreeRegGainCiLowFeb` | 11.67 | `QthreeRegGainPctAug` | 28.00 |
| `QthreeRegGainPctFeb` | 12.35 | `QthreeRows` | 2303 |
| `QthreeSelectedKeywordDays` | 2303 | `QthreeSelectedKeywordsAug` | 535 |
| `QthreeSelectedKeywordsFeb` | 73 | `QthreeUnitDaysAug` | 91 |
| `QthreeUnitDaysFeb` | 16 | `QthreeUnitsAug` | 12 |
| `QthreeUnitsFeb` | 2 | `QthreeWindowGainPctAug` | 11.25 |
| `QthreeWindowGainPctFeb` | 0.82 | `QthreeWindowRegsAug` | 2489.11 |
| `QthreeWindowRegsFeb` | 520.64 |  |  |

### `classify` 阶段登记的数字（28 个）

| 键 | 值 | 键 | 值 |
|---|---|---|---|
| `AgreementGmmJenksPct` | 93.53 | `AgreementJenksEqualWeightsPct` | 99.19 |
| `AgreementJenksMedianPct` | 78.36 | `BenefitThreshold` | 0.2758 |
| `CostThresholdLog` | 1.6190 | `CostThresholdYuan` | 41.59 |
| `EntropyEqualSpearman` | 0.9995 | `GmmCostThresholdYuan` | 107.51 |
| `GoldCount` | 40 | `GoldCpc` | 0.7192 |
| `GoldSpendSharePct` | 0.08 | `InvalidCount` | 890 |
| `InvalidCpc` | 0.0000 | `InvalidSpendSharePct` | 0.00 |
| `KeyCount` | 271 | `KeyCpc` | 1.7143 |
| `KeySpendSharePct` | 99.11 | `MedianCostThresholdYuan` | 8.06 |
| `PotentialCount` | 977 | `PotentialCpc` | 1.0599 |
| `PotentialSpendSharePct` | 0.53 | `ProblemCount` | 49 |
| `ProblemCpc` | 2.2313 | `ProblemSpendSharePct` | 0.28 |
| `WeightClicks` | 0.1966 | `WeightEngagement` | 0.2849 |
| `WeightReg` | 0.3092 | `WeightViews` | 0.2093 |

### `eda` 阶段登记的数字（119 个）

| 键 | 值 | 键 | 值 |
|---|---|---|---|
| `ActiveKeywords` | 1337 | `AdjustedWorkdayRegEffectPct` | -2.42 |
| `AdjustedWorkdayRegP` | 0.9419 | `AttributedRegs` | 60,269 |
| `AttributedRegsSharePct` | 70.65 | `AttributionHoldoutMape` | 30.19 |
| `AttributionHoldoutRsq` | 0.7375 | `AttributionLambda` | 0.0 |
| `AttributionRsq` | 0.7951 | `BaselineRegsPerDay` | 151.39 |
| `BiggestUnitId` | 9657930100 | `BiggestUnitSpendSharePct` | 56.67 |
| `CostPerAttributedReg` | 23.66 | `FirstSharePct` | 10.39 |
| `GiniSpendActive` | 0.9676 | `HolidayClicksCiHigh` | -68.17 |
| `HolidayClicksCiLow` | -81.61 | `HolidayClicksEffectPct` | -75.81 |
| `HolidayClicksP` | 0.0000 | `HolidayClicksPSci` | 3.9e-24 |
| `HolidayCpcEffect` | -0.0240 | `HolidayCpcP` | 0.8043 |
| `HolidayCtrEffectPp` | -0.242 | `HolidayCtrP` | 0.5740 |
| `HolidayDays` | 28 | `HolidayImpCiHigh` | -63.68 |
| `HolidayImpCiLow` | -76.49 | `HolidayImpEffectPct` | -70.78 |
| `HolidayImpP` | 0.0000 | `HolidayImpPSci` | 1.5e-28 |
| `HolidayOptimalSpendCutPct` | 64.0 | `HolidayOptimalSpendRatioPct` | 36.0 |
| `HolidayRegCiHigh` | -65.47 | `HolidayRegCiLow` | -79.99 |
| `HolidayRegEffectPct` | -73.72 | `HolidayRegGivenSpendCiHigh` | -5.32 |
| `HolidayRegGivenSpendCiLow` | -40.01 | `HolidayRegGivenSpendEffectPct` | -24.64 |
| `HolidayRegGivenSpendP` | 0.0151 | `HolidayRegMannWhitneyP` | 4.56e-14 |
| `HolidayRegMedian` | 58 | `HolidayRegMedianRatio` | 0.2140 |
| `HolidayRegP` | 0.0000 | `HolidayRegPSci` | 8.0e-22 |
| `HolidaySpendCiHigh` | -67.61 | `HolidaySpendCiLow` | -83.21 |
| `HolidaySpendEffectPct` | -76.68 | `HolidaySpendP` | 0.0000 |
| `HolidaySpendPSci` | 3.9e-18 | `HolidayTopEffectPp` | -4.64 |
| `HolidayTopP` | 0.0432 | `KeywordRows` | 2227 |
| `MaxUnitCpc` | 2.25 | `MaxUnitGamma` | 0.9301 |
| `MaxUnitGammaRsq` | 0.97 | `MinCtrUnitCtrPct` | 0.74 |
| `MinCtrUnitId` | 4190988309 | `MinUnitCpc` | 0.74 |
| `MinUnitGamma` | 0.6502 | `MinUnitGammaRsq` | 0.65 |
| `MondayCpcEffect` | -0.2360 | `MondayCpcP` | 0.0023 |
| `MondayRegEffectPct` | -53.81 | `MondayRegGivenSpendEffectPct` | -10.85 |
| `MondayRegGivenSpendP` | 0.2665 | `MondayRegP` | 0.0000 |
| `OtherCpc` | 1.5377 | `OtherRegionCtrPct` | 1.67 |
| `OverallCpc` | 1.7081 | `OverallCtrPct` | 3.70 |
| `PlansCount` | 5 | `PooledGamma` | 0.8355 |
| `PooledGammaSe` | 0.0113 | `PooledRegRatePerHundredClicks` | 7.9475 |
| `PostHolidayRegEffectPct` | -17.29 | `PostHolidayRegP` | 0.4100 |
| `PreHolidayRegEffectPct` | -54.34 | `PreHolidayRegP` | 0.1482 |
| `RegCalendarRsq` | 0.4802 | `RegGivenSpendRsq` | 0.7829 |
| `RegSpendElasticity` | 0.7235 | `RegSpendElasticitySe` | 0.0631 |
| `RegWeekdayWaldP` | 3.53e-12 | `SaturdayRegEffectPct` | -12.64 |
| `SaturdayRegP` | 0.1561 | `SharedKeywordIds` | 290 |
| `SharedKeywordRows` | 633 | `SpendCalendarRsq` | 0.5201 |
| `SundayRegEffectPct` | -47.36 | `SundayRegGivenSpendEffectPct` | -9.86 |
| `SundayRegGivenSpendP` | 0.2684 | `SundayRegP` | 0.0000 |
| `TopClickSharePct` | 67.06 | `TopCpc` | 1.7918 |
| `TopCtrUnitCpc` | 0.74 | `TopCtrUnitCtrPct` | 66.1 |
| `TopCtrUnitId` | 8878077181 | `TopCtrUnitKeywords` | 4 |
| `TopCtrUnitTopSharePct` | 88.6 | `TopHundredSpendSharePct` | 96.40 |
| `TopRegionCtrPct` | 9.15 | `TopSharePct` | 27.11 |
| `TopSpendSharePct` | 70.35 | `TopTenSpendSharePct` | 58.41 |
| `TotalClicks` | 834,815 | `TotalImpressions` | 22,580,381 |
| `TotalRegs` | 85,313 | `TotalSpend` | 1,425,949.79 |
| `TotalSpendWan` | 142.59 | `UniqueKeywordIds` | 1884 |
| `UnitDays` | 2627 | `UnitsCount` | 12 |
| `UnitsWithOwnGamma` | 10 | `UnitsWithOwnRate` | 5 |
| `WorkdayDays` | 243 | `WorkdayRegMedian` | 271 |
| `ZeroKeywordSharePct` | 40.0 | `ZeroKeywords` | 890 |
| `ZeroSpendUnitDays` | 293 |  |  |

### `forecast` 阶段登记的数字（73 个）

| 键 | 值 | 键 | 值 |
|---|---|---|---|
| `BacktestCalendarCoverageClicks` | 87.26 | `BacktestCalendarCoverageCpc` | 81.83 |
| `BacktestCalendarCoverageCtr` | 78.93 | `BacktestCalendarCoverageEff` | 81.30 |
| `BacktestCalendarCoverageTop` | 78.34 | `BacktestCalendarMaeClicks` | 0.4805 |
| `BacktestCalendarMaeCpc` | 0.2932 | `BacktestCalendarMaeCtr` | 0.4368 |
| `BacktestCalendarMaeEff` | 0.2361 | `BacktestCalendarMaeTop` | 0.6403 |
| `BacktestCalendarPinballClicks` | 0.2528 | `BacktestCalendarPinballCpc` | 0.1987 |
| `BacktestCalendarPinballCtr` | 0.2720 | `BacktestCalendarPinballEff` | 0.1572 |
| `BacktestCalendarPinballTop` | 0.3939 | `BacktestMeanCoverageClicks` | 73.98 |
| `BacktestMeanCoverageCpc` | 63.63 | `BacktestMeanCoverageCtr` | 80.31 |
| `BacktestMeanCoverageEff` | 68.85 | `BacktestMeanCoverageTop` | 70.16 |
| `BacktestMeanMaeClicks` | 0.5772 | `BacktestMeanMaeCpc` | 0.2426 |
| `BacktestMeanMaeCtr` | 0.2710 | `BacktestMeanMaeEff` | 0.1874 |
| `BacktestMeanMaeTop` | 0.4521 | `BacktestNaiveCoverageClicks` | 90.20 |
| `BacktestNaiveCoverageCpc` | 88.74 | `BacktestNaiveCoverageCtr` | 91.24 |
| `BacktestNaiveCoverageEff` | 90.06 | `BacktestNaiveCoverageTop` | 90.22 |
| `BacktestNaiveMaeClicks` | 0.4796 | `BacktestNaiveMaeCpc` | 0.2525 |
| `BacktestNaiveMaeCtr` | 0.3048 | `BacktestNaiveMaeEff` | 0.2142 |
| `BacktestNaiveMaeTop` | 0.4834 | `BacktestNaivePinballClicks` | 0.3038 |
| `BacktestNaivePinballCpc` | 0.1913 | `BacktestNaivePinballCtr` | 0.1794 |
| `BacktestNaivePinballEff` | 0.1399 | `BacktestNaivePinballTop` | 0.2849 |
| `QfourAuditGroups` | 75 | `QfourBiggestUnitBudgetSharePct` | 81.1 |
| `QfourBiggestUnitId` | 9657930100 | `QfourBudget` | 23,488.02 |
| `QfourBudgetAnnualAlt` | 27,346.98 | `QfourClickGainVsRefPct` | 36.17 |
| `QfourClicksHigh` | 21,970.2 | `QfourClicksLow` | 13,547.4 |
| `QfourClicksMean` | 17,487.9 | `QfourCpcHigh` | 1.7337 |
| `QfourCpcLow` | 1.0691 | `QfourCpcMean` | 1.3431 |
| `QfourImpHigh` | 1,168,717.5 | `QfourImpLow` | 362,488.7 |
| `QfourImpMean` | 721,553.1 | `QfourPositionMean` | 2.6126 |
| `QfourPositionLow` | 2.2486 | `QfourPositionHigh` | 3.1264 |
| `QfourRefClicks` | 12,843 | `QfourRegsExpectedAnnualAlt` | 2327.0 |
| `QfourRegsExpectedSamePeriod` | 1187.4 | `QfourRegsGainAnnualAltPct` | 96.0 |
| `QfourRegsHigh` | 1,495.3 | `QfourRegsLow` | 922.9 |
| `QfourRegsMean` | 1,194.4 | `QfourRows` | 845 |
| `QfourScenarios` | 500 | `QfourSelectedKeywords` | 146 |
| `QfourSkippedUnits` | 2 | `QfourUnits` | 10 |
| `QfourViewsHigh` | 121,848.9 | `QfourViewsLow` | 69,297.8 |
| `QfourViewsMean` | 93,916.4 |  |  |


## v1.0.1 审稿修订新增/更新的登记数字

run `20260912-041501-ae773aa`（最终发布口径；lint / test / paper / qa / package / release 全绿，53 项测试通过，qa 15 项检查全部通过）。下表只列本轮新增或改口径的键，其余键见上文。

| 键 | 值 | 键 | 值 |
|---|---|---|---|
| `AttributionBoot` | 300 | `AttributionConditionNumber` | 948 |
| `AttributionHoldoutMape` | 30.19 | `AttributionHoldoutRsq` | 0.7375 |
| `AttributionLambda` | 0.0 | `AttributionMaxSwingRatio` | 3.6 |
| `AttributionRsq` | 0.7951 | `AttributionZeroBoundUnits` | 6 |
| `AxisEfficiencyAgreementPct` | 83.79 | `AxisPearson` | 0.9297 |
| `AxisPearsonRsq` | 0.864 | `AxisSpearman` | 0.9021 |
| `AxisSpearmanClicks` | 0.9209 | `AxisSpearmanEfficiency` | -0.4719 |
| `BacktestCalendarCoverageMax` | 87.3 | `BacktestCalendarCoverageMin` | 78.3 |
| `BacktestMeanCoverageMax` | 80.3 | `BacktestMeanCoverageMin` | 63.6 |
| `BacktestOrigins` | 12 | `BacktestUnits` | 11 |
| `BacktestWideCoverageClicks` | 92.06 | `BacktestWideCoverageCpc` | 88.49 |
| `BacktestWideCoverageCtr` | 87.93 | `BacktestWideCoverageEff` | 86.78 |
| `BacktestWideCoverageFirst` | 90.70 | `BacktestWideCoverageMax` | 92.1 |
| `BacktestWideCoverageMin` | 86.8 | `BacktestWideCoverageTop` | 87.55 |
| `BacktestWidePinballClicks` | 0.3106 | `BacktestWidePinballCpc` | 0.2010 |
| `BacktestWidePinballCtr` | 0.2936 | `BacktestWidePinballEff` | 0.1593 |
| `BacktestWidePinballFirst` | 0.3872 | `BacktestWidePinballTop` | 0.4083 |
| `DecompCalendarPct` | -33.8 | `DecompCalendarRegs` | -28,873 |
| `DecompInterceptPct` | 64.8 | `DecompInterceptRegs` | 55,257 |
| `DecompNonSemPerDay` | 72.3 | `DecompSemPct` | 69.1 |
| `DecompSemRegs` | 58,929 | `EffGoldCount` | 58 |
| `EffInvalidCount` | 890 | `EffKeyCount` | 2 |
| `EffPotentialCount` | 959 | `EffProblemCount` | 318 |
| `EngagementVariantAgreementPct` | 95.55 | `GammaAboveOneActiveDays` | 223 |
| `GammaAboveOneHat` | 1.3253 | `GammaAboveOneSe` | 0.0658 |
| `GammaAboveOneT` | 4.94 | `GammaAboveOneUnitId` | 8878077181 |
| `GammaMinActiveDays` | 56 | `GammaShortActiveDays` | 56 |
| `GammaShortDays` | 56 | `GammaShortHat` | 0.4937 |
| `GammaShortUnitId` | 2526158329 | `GoldClickSharePct` | 0.1786 |
| `GoldSpendSharePctFine` | 0.0752 | `HolidayActualCutPct` | 76.7 |
| `HolidayCutAtPooledGammaPct` | 82.1 | `HolidayDemandDeltaCiHighPct` | -5.32 |
| `HolidayDemandDeltaCiLowPct` | -40.01 | `HolidayDemandLogSharePct` | 21 |
| `HolidayOptimalCutCiHighPct` | 76.6 | `HolidayOptimalCutCiLowPct` | 26.9 |
| `HolidayOptimalCutPct` | 64.0 | `HolidayOptimalSpendCutPct` | 64.0 |
| `HolidayOptimalSpendRatioPct` | 36.0 | `HolidayProbOptimalDeeperPct` | 2 |
| `HolidaySupplyLogSharePct` | 79 | `HolidayThetaStar` | 0.8057 |
| `HolidayThetaStarInsideCi` | 1 | `InvalidClickSharePct` | 0.0000 |
| `KappaAtBoundPct` | 43.7 | `KappaMedian` | 0.6296 |
| `KappaRows` | 1,337 | `KeyClickSharePct` | 98.7511 |
| `MaxPninefiveSpendRatio` | 8.07 | `MaxUnitGammaHat` | 1.3253 |
| `MedianPninefiveSpendRatio` | 2.67 | `MinPninefiveSpendRatio` | 1.74 |
| `MinUnitGammaHat` | 0.4937 | `MondayActualCutPct` | 59.7 |
| `MondayCutAtPooledGammaPct` | 50.2 | `MondayDemandDeltaCiHighPct` | 9.17 |
| `MondayDemandDeltaCiLowPct` | -27.19 | `MondayOptimalCutCiHighPct` | 68.5 |
| `MondayOptimalCutCiLowPct` | -48.7 | `MondayOptimalCutPct` | 34.0 |
| `MondayProbOptimalDeeperPct` | 9 | `MondayThetaStar` | 0.8737 |
| `OtherRegionClickSharePct` | 32.94 | `OtherRegionCtrPct` | 1.67 |
| `OtherRegionImpSharePct` | 72.89 | `PotentialClickSharePct` | 0.8524 |
| `ProblemClickSharePct` | 0.2179 | `QfourAltClicks` | 25,130.3 |
| `QfourAltKeywords` | 274 | `QfourAltRegs` | 2327.0 |
| `QfourAltRows` | 1803 | `QfourAltSpend` | 27,346.63 |
| `QfourAltUnits` | 12 | `QfourBudgetAltOverMainPct` | 16.4 |
| `QfourCpcScenarioMean` | 1.5735 | `QfourDetRegs` | 1187.4 |
| `QfourJointBigUnits` | 7 | `QfourJointGapPct` | 0.822 |
| `QfourJointMaxGapBigPct` | 2.08 | `QfourJointMaxGapPct` | 27.49 |
| `QfourJointMaxGapUnit` | 2526158329 | `QfourJointMaxGapUnitRegs` | 0.52 |
| `QfourJointUnits` | 10 | `QfourPfirstPct` | 36.0 |
| `QfourPmidPct` | 20.5 | `QfourPtopPct` | 56.5 |
| `QfourRegsMcSe` | 5.8 | `QfourRegsMcZ` | 1.2 |
| `QfourWidthInflationMax` | 4.460 | `QfourWidthInflationMedian` | 1.536 |
| `QfourWidthInflationMin` | 1.069 | `QthreeCrossUnitDaysAug` | 8 |
| `QthreeCrossUnitDaysFeb` | 8 | `QthreeCrossUnitGainPctAug` | 32.31 |
| `QthreeCrossUnitGainPctFeb` | 3.97 | `QthreeDupBestGainPctAug` | 24.65 |
| `QthreeDupBestGainPctFeb` | 12.32 | `QthreeDupKeywordDays` | 75 |
| `QthreeDupRegs` | 449.31 | `QthreeDupRegsSharePct` | 16.32 |
| `QthreeDupSpend` | 7,240.11 | `QthreeDupSpendSharePct` | 14.15 |
| `QthreeFebAltBudget` | 31,252.92 | `QthreeFebAltClicks` | 18,914.9 |
| `QthreeFebAltKeywords` | 519 | `QthreeFebAltRegs` | 1866.83 |
| `QthreeFebAltRows` | 2271 | `QthreeFebAltUnits` | 12 |
| `QthreeFloorCostPctAug` | 0.116 | `QthreeFloorCostPctFeb` | 0.019 |
| `QthreeGainRescaledPctAug` | 34.61 | `QthreeGainRescaledPctFeb` | 12.50 |
| `QthreeGainShiftPp` | 6.62 | `QthreeKappaClipGainPctAug` | 27.13 |
| `QthreeKappaClipGainPctFeb` | 12.06 | `QthreeKappaOneGainPctAug` | 26.89 |
| `QthreeKappaOneGainPctFeb` | 11.75 | `QthreeMinOptPropRatio` | 1.0062 |
| `QthreePropBelowFloor` | 11,301 | `QthreePropBelowFloorPct` | 87.5 |
| `QthreePropClicksAug` | 24,784.5 | `QthreePropClicksFeb` | 6,335.2 |
| `QthreePropCpcAug` | 1.5124 | `QthreePropCpcFeb` | 2.1595 |
| `QthreePropPositiveCoords` | 12,917 | `QthreePropRegsAug` | 1748.04 |
| `QthreePropRegsFeb` | 459.65 | `QthreeSelectedBaseAug` | 21.7 |
| `QthreeSelectedBaseFeb` | 20.4 | `QthreeSelectedNoFloorAug` | 116.8 |
| `QthreeSelectedNoFloorFeb` | 143.0 | `QthreeSensMaxGainPct` | 36.4 |
| `QthreeSensMinGainPct` | 9.0 | `QthreeSensScenarios` | 14 |
| `QthreeSignedBiasPctAug` | -30.8 | `QthreeSignedBiasPctFeb` | 12.0 |
| `QthreeSpendWeightedMape` | 30.6 | `QthreeUnitDaysOptAtLeastProp` | 107 |
| `SundayActualCutPct` | 52.5 | `SundayCutAtPooledGammaPct` | 46.8 |
| `SundayDemandDeltaCiHighPct` | 8.33 | `SundayDemandDeltaCiLowPct` | -24.99 |
| `SundayOptimalCutCiHighPct` | 58.7 | `SundayOptimalCutCiLowPct` | -53.0 |
| `SundayOptimalCutPct` | 31.3 | `SundayProbOptimalDeeperPct` | 8 |
| `SundayThetaStar` | 0.8604 | `ThetaCiHigh` | 0.8471 |
| `ThetaCiLow` | 0.5998 | `TopOverOtherCtrRatio` | 5.5 |
| `UnitsGammaHatAboveOne` | 1 | `UnitsGammaHatBelowOne` | 10 |
共 182 个新增键；全部 456 个键见各阶段 numbers.json。
