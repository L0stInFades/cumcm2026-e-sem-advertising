# 复现说明（run `20260912-041501-ae773aa`）

本目录内所有结果均由 Modal 云端按下列阶段生成；本地只提交任务、下载和核对 SHA-256。

- 代码版本：git `a3b24eecc2ad194455f12952bd3d53266e63a8e8`（分支 `main`）
- 运行环境：Python 3.11.12，Linux-4.19.0-gvisor-x86_64-with-glibc2.36
- 依赖版本：cvxpy==1.6.5, highspy==1.10.0, hypothesis==6.131.9, matplotlib==3.10.3, mypy==1.15.0, networkx==3.4.2, numba==0.61.2, numpy==2.2.6, openpyxl==3.1.5, ortools==9.12.4544, pandas==2.2.3, pyarrow==20.0.0, pymupdf==1.26.7, pytest==8.3.5, ruff==0.11.10, scikit-learn==1.6.1, scipy==1.15.3, statsmodels==0.14.4

## 阶段

| 阶段 | 状态 | 用时 (s) | 输出摘要 | Modal 任务 |
|---|---|---:|---|---|
| allocate | completed | 63.0 | `724259d703dc30b5` | `ta-01M2A78A6ADGMXBYBQKAWA9RPR` |
| classify | completed | 1.0 | `09b0ee01107ba8e7` | `ta-01M2A5NW550BF8S87FP0NXP8ER` |
| eda | completed | 3.0 | `de671c38a6462570` | `ta-01M2A6XWCPB4CBJ1BH7MGQ969R` |
| figures | completed | 27.0 | `a50aedf500ef32de` | `ta-01M2A7K6VWXTF6V38QW4G10RDR` |
| fmt | completed | 0.0 | `c99da4ff4596b2f7` | `ta-01M2A7YHRPDHA1NC9C8E8YZDHR` |
| forecast | completed | 13.0 | `b7ee2ae20550f38e` | `ta-01M2A78A6ADGMXBYBQKAWA9RPR` |
| ingest | completed | 1.0 | `02e38a853d4c7bbd` | `ta-01M2921SRRS59ZGNGZWMNNKSSR` |
| lint | completed | 21.0 | `a9c8365db560dfe6` | `ta-01M2A7ZFKHQFTVEB1QFH8T13KR` |
| package | 本表由该阶段渲染，故为 running | 0.0 | `` | `ta-01M2A8AGMQ2025VS23B7AVG8TR` |
| paper | completed | 79.0 | `8e555755ead94e1d` | `ta-01M2A7ZFKHQFTVEB1QFH8T13KR` |
| qa | completed | 1.0 | `ba1d8b4bf4a5c44e` | `ta-01M2A7ZFKHQFTVEB1QFH8T13KR` |
| release | 本表生成后才执行（见第 8 节与发布清单） | 0.0 | `` | `ta-01M2A7ZFKHQFTVEB1QFH8T13KR` |
| results | completed | 2.0 | `79ce6f23421e94aa` | `ta-01M2A78A6ADGMXBYBQKAWA9RPR` |
| tables | completed | 0.0 | `01fba99d8e19e9ba` | `ta-01M2A78A6ADGMXBYBQKAWA9RPR` |
| test | completed | 21.0 | `9266c519460123b5` | `ta-01M2A7ZFKHQFTVEB1QFH8T13KR` |
| validate | completed | 0.0 | `8ad89df6a5eca27a` | `ta-01M2921SRRS59ZGNGZWMNNKSSR` |

## 复现命令

```bash
python3 tools/cli.py provision
python3 tools/cli.py run ingest,validate --new-run
python3 tools/cli.py run allocate,classify,eda,figures,forecast,results,tables --size medium
python3 tools/cli.py run lint,test,paper,qa,package,release
python3 tools/cli.py release --version <tag>
```

每个阶段目录下的 `manifest.json` 记录输入、输出散列、参数与环境；`events.jsonl` 为结构化日志。
